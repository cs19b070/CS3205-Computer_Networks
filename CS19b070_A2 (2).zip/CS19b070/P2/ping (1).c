#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/ip_icmp.h>
#include <time.h>
#include <signal.h>

// Define the Packet Constants

#define PKT_SIZE 64							
#define PORT_NO 0									
#define SLEEP_RATE 1000000		
#define RECV_TIMEOUT 1						

// Define the Ping Loop
int pingloop=1;


// Ping packet structure
struct ping_pkt{
	struct icmphdr hdr;
	char msg[PKT_SIZE-sizeof(struct icmphdr)];
};

// Calculating the Check Sum
unsigned short checksum(void *b, int len){
	unsigned short *buf = b;
	unsigned int sum=0;
	unsigned short result;

	for ( sum = 0; len > 1; len -= 2 )
		sum += *buf++;
	if ( len == 1 )
		sum += *(unsigned char*)buf;
	sum = (sum >> 16) + (sum & 0xFFFF);
	sum += (sum >> 16);
	result = ~sum;
	return result;
}

// Interrupt handler
void intrupt_Handler(int temp){
	pingloop=0;
}

// make a ping request
void ping(int sockfd, struct sockaddr_in *ping_addr, char *ping_ip){
	int ttl_val=64, pkt_sent=0, i, addr_len, flag=1, pkt_received=0;
	
	struct ping_pkt pkt;
	struct sockaddr_in r_addr;
	struct timespec pkt_start, pkt_end, ping_start, ping_end;
	long double rtt_msec=0, total_msec=0;

	
	struct timeval tv_out;
	tv_out.tv_sec = RECV_TIMEOUT;
	tv_out.tv_usec = 0;

	clock_gettime(CLOCK_MONOTONIC, &ping_start);
	
	
	if (setsockopt(sockfd, SOL_IP, IP_TTL, &ttl_val, sizeof(ttl_val)) != 0){
		printf("\nSetting socket options to TTL failed!\n");
		return;
	}
	else{
		printf("\nSocket set to TTL=%d\n", ttl_val);
	}

	
	setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv_out, sizeof tv_out);

		
		flag=1;
	
		//filling packet
		bzero(&pkt, sizeof(pkt));
		
		pkt.hdr.type = ICMP_ECHO;
		pkt.hdr.un.echo.id = getpid();
		
		for (int i = 0; i < sizeof(pkt.msg); i++ )
			if(i == sizeof(pkt.msg)-1)
				pkt.msg[i] = 0;
			else
				pkt.msg[i] = i+'A';
		
		pkt.hdr.un.echo.sequence = pkt_sent++;
		pkt.hdr.checksum = checksum(&pkt, sizeof(pkt));

		usleep(SLEEP_RATE);

		//send packet
		clock_gettime(CLOCK_MONOTONIC, &pkt_start);
		if(sendto(sockfd, &pkt, sizeof(pkt), 0,(struct sockaddr*) ping_addr, sizeof(*ping_addr)) <= 0){
			printf("\nPacket Sending Failed!\n");
			flag=0;
		}

		//receive packet
		addr_len=sizeof(r_addr);
		if(recvfrom(sockfd, &pkt, sizeof(pkt), 0, (struct sockaddr*)&r_addr, &addr_len) <= 0 && pkt_sent>0 && flag){
			printf("Packet receive failed!\n");
		}
		else{
			clock_gettime(CLOCK_MONOTONIC, &pkt_end);
			
			rtt_msec = (pkt_end.tv_sec-pkt_start.tv_sec) * 1000.0 + ((double)(pkt_end.tv_nsec - pkt_start.tv_nsec))/1000000.0;
			
			// if packet was not sent, don't receive
			if(flag){
				if(!(pkt.hdr.type == 69 && pkt.hdr.code == 0)){
					if(pkt.hdr.type == 3 || pkt.hdr.type == 11)
						printf("\nRequest timed out or host unreacheable\n");
					else
						printf("Error..Packet received with ICMPtype %d code %d\n", pkt.hdr.type, pkt.hdr.code);
				}
				else{
					printf("%d bytes from '%s' msg_seq=%d ttl=%d rtt=%Lf ms.\n", PKT_SIZE, ping_ip, pkt_sent, ttl_val, rtt_msec);
					pkt_received++;
				}
			}
		}	
	
	clock_gettime(CLOCK_MONOTONIC, &ping_end);
	total_msec = (ping_end.tv_sec-ping_start.tv_sec)*1000.0 + ((double)(ping_end.tv_nsec - ping_start.tv_nsec))/1000000.0;
					
	printf("\n--- %s ping statistics ---\n", ping_ip);
	printf("%d packets transmitted, %d received, %.2f %% packet loss, time %.0LFms\n", pkt_sent, pkt_received, ((pkt_sent - pkt_received)/pkt_sent) * 100.0, total_msec);
}

// Driver Code
int main(int argc, char *argv[]){
	int sockfd;
	struct sockaddr_in addr_con;

	if(argc!=2){
		printf("Error in Format");
		printf("\nCorrect Format: %s <ip>\n", argv[0]);
		return 0;
	}

	if(gethostbyname(argv[1]) == NULL){
		printf("Bad hostname\n");
		return 0;
	}

	// assign IP, PORT
	addr_con.sin_family = AF_INET;
	addr_con.sin_port = htons (PORT_NO);
	addr_con.sin_addr.s_addr = inet_addr(argv[1]);

	printf("\nConnecting to '%s'", argv[1]);

	// create socket
	if((sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP))<0){
		printf("\nSocket creation failed\n");
		return 0;
	}
	else
		printf("\nSocket created with fd=%d \n", sockfd);

	//catching interrupt
	signal(SIGINT, intrupt_Handler);	

	//send pings continuously
	ping(sockfd, &addr_con, argv[1]);

	return 0;
}

