import math

message = open("message.txt", "r").read().strip()
messageInBinary = bin(int(message, 16))[2:].zfill(4*len(message))

Blocks = [messageInBinary[i:i+40] for i in range(0, len(messageInBinary), 40)]
numberOfParityBitsPerBlock = math.floor(math.log(len(Blocks[0]), 2))
BitFlipIdxs = []
parityBitIndexes = [[1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37], [2, 3, 6, 7, 10, 11, 14, 15, 18, 19, 22, 23, 26, 27, 30, 31, 34, 35, 38], [4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31, 36, 37, 38], [8, 9, 10, 11, 12, 13, 14, 15, 24, 25, 26, 27, 28, 29, 30, 31], [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31], [32, 33, 34, 35, 36, 37, 38]]

for block in Blocks:
    dataBlock = block[1:-1]
    parity = ''
    for i in range(numberOfParityBitsPerBlock+1):
        parityBit = False
        for j in parityBitIndexes[i]:
            if dataBlock[j-1] == '1':
                parityBit = not parityBit
        if parityBit:
            parity = '1' + parity
        else:
            parity = '0' + parity

    BitFlipIdxs.append(int(parity,2))

for i in range(len(Blocks)):
	if BitFlipIdxs[i] > 0:
		new = list(Blocks[i])
		if new[BitFlipIdxs[i]] == '1':
			new[BitFlipIdxs[i]] = '0'
		else:
			new[BitFlipIdxs[i]] = '1'
		Blocks[i] = ''.join(new)

BlocksTexts = []

R = [2**p for p in range(numberOfParityBitsPerBlock+1)]

for i in range(len(Blocks)):
	BlocksTexts.append("".join([char for idx, char in enumerate(Blocks[i][1:-1]) if idx+1 not in set(R)]))

originalMessage = ''
for BlocksText in BlocksTexts:

	textInDec = int(BlocksText, 2)
	originalMessage += textInDec.to_bytes((textInDec.bit_length() + 7 // 8), "big").decode()

BitFlipIdxs = [x for x in BitFlipIdxs if x != 0]

print("Text:", originalMessage.lower())
print("Code Word:", message)
if len(BitFlipIdxs) == 0:
    print("Bit_Flip_idx: Not Flipped")
else:
    print("Bit_Flip_idx:", BitFlipIdxs)
print("Num_Blocks:", len(Blocks))
