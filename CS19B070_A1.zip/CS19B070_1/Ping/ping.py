import geocoder
from numpy import average
from haversine import haversine
from pythonping import ping
import matplotlib.pyplot as plt
from scipy import constants
import math

file = open("ping-servers.txt", "r")
ping_servers = file.read().split("\n")

dOutput = open("distance.txt", "w")
dOutput.write("<--Own IP-->\t\t<--Server IP-->\t\t<--Distance-->\n\n")
rttOutput = open("rtt.txt", "w")
rttOutput.write("<---Your Location--->\t\t<---Server--->\t\t<---Server Location--->\t\t<---RTT1,RTT2,...,RTT10--->\n\n")

src = geocoder.ip('me')

rttLight = []
factor = []

for i in range(len(ping_servers)):
	dest = geocoder.ip(ping_servers[i])
	res = ping(ping_servers[i], count=10, timeout = 1)
	dist = haversine(src.lng, src.lat, dest.lng, dest.lat)
	rtt = []
	for i in res:
		rtt.append(round(i.time_elapsed*1000, 2))
	dOutput.write(f"{src.ip}\t\t{dest.ip}\t\t{dist}\n")
	rttOutput.write(f"{src.latlng}\t\t{dest.ip}\t\t{dest.latlng}\t\t{rtt}\n")
	factor.append((res.rtt_avg_ms/round(dist/constants.c*(10**6), 2)))
	rttLight.append(round(dist/constants.c*(10**6), 2))
	plt.scatter(res.rtt_avg_ms, dist)

plt.show()
plt.savefig('plot.png')

print(average(factor))